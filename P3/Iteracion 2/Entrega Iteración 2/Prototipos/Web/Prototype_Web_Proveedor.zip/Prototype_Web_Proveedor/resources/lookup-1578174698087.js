(function(window, undefined) {
  var dictionary = {
    "3271ed72-dfd4-43ab-a621-213bc153f73d": "Subastas",
    "63fbbd0d-84cb-42f1-abfd-348e89aeaaa7": "Servicios_Crear",
    "d96e797b-c84d-4b21-8600-5a73454b3316": "Evento-Detalles",
    "a78b7b14-0572-445a-b0fa-7c9ef79dc414": "Servicios_detalles",
    "dbc1bf04-3315-4276-8c1b-e293d85b600c": "Subastas_Editar",
    "81a6c3c2-cd0e-4573-aa09-4b1b541d86ec": "Subastas_Crear",
    "4b58098c-2e17-4cde-a4a9-33eb139662a4": "Configuracion",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Home",
    "b1c10549-6910-4cf8-878d-b5789e562d95": "Login",
    "f6e4e648-a8e3-4c00-aa42-68ca44600862": "Eventos-Subastas",
    "b87aa42a-6e1d-486b-80fd-6ed956b49bd6": "Onboarding",
    "7686416f-b060-4211-87c8-35b7bdc23277": "Servicios",
    "b0baafc4-55b1-45c1-bdde-8f468a6635b4": "Register",
    "f2afab6c-1a61-4eb8-a4b7-00046ca23ca4": "Servicios_Editar",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "7d26d58f-ecbf-4196-86c1-2310ac1bb915": "Master",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);