jQuery("#simulation")
  .on("click", ".m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#m-7d26d58f-Hotspot_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Paragraph_9")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "180"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "timed",
          "delay": 3000
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Paragraph_10")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_4" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_4" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "timed",
          "delay": 3000
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_13")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_14")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7686416f-b060-4211-87c8-35b7bdc23277"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_15")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/f6e4e648-a8e3-4c00-aa42-68ca44600862"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_16")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3271ed72-dfd4-43ab-a621-213bc153f73d"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_22")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimRotate",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Image_17" ],
                    "angle": {
                      "type": "rotateto",
                      "value": "360"
                    },
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 300
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#m-7d26d58f-Group_3" ],
                    "effect": {
                      "type": "slide",
                      "duration": 300,
                      "direction": "up"
                    }
                  },
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/4b58098c-2e17-4cde-a4a9-33eb139662a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Hotspot_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a78b7b14-0572-445a-b0fa-7c9ef79dc414"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Hotspot_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/3271ed72-dfd4-43ab-a621-213bc153f73d"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Hotspot_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/4b58098c-2e17-4cde-a4a9-33eb139662a4"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("mouseenter dragenter", ".m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 .mouseenter", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#m-7d26d58f-Paragraph_9") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_9": {
                      "attributes": {
                        "line-height": "24px",
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_9 .valign": {
                      "attributes": {
                        "vertical-align": "top",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_9 span": {
                      "attributes": {
                        "color": "#19BDD3",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Image_17 > svg": {
                      "attributes": {
                        "overlay": "#19BDD3"
                      }
                    }
                  } ],
                  "exectype": "parallel",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Paragraph_10") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_10": {
                      "attributes": {
                        "line-height": "24px",
                        "font-size": "11.0pt",
                        "font-family": "'Roboto-Regular',Arial"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_10 .valign": {
                      "attributes": {
                        "vertical-align": "top",
                        "text-align": "left"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Paragraph_10 span": {
                      "attributes": {
                        "color": "#19BDD3",
                        "text-align": "left",
                        "text-decoration": "none",
                        "font-family": "'Roboto-Regular',Arial",
                        "font-size": "11.0pt"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_13") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_13 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#E2E2E2"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_13": {
                      "attributes-ie": {
                        "-pie-background": "#E2E2E2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_14") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_14 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#E2E2E2"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_14": {
                      "attributes-ie": {
                        "-pie-background": "#E2E2E2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_15") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_15 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#E2E2E2"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_15": {
                      "attributes-ie": {
                        "-pie-background": "#E2E2E2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_16") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_16 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#E2E2E2"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_16": {
                      "attributes-ie": {
                        "-pie-background": "#E2E2E2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_22") && jFirer.has(event.relatedTarget).length === 0) {
      event.backupState = true;
      event.target = jFirer;
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_22 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#E2E2E2"
                      }
                    }
                  },{
                    "#m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 #m-7d26d58f-Rectangle_22": {
                      "attributes-ie": {
                        "-pie-background": "#E2E2E2",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      jEvent.launchCases(cases);
    }
  })
  .on("mouseleave dragleave", ".m-7d26d58f-ecbf-4196-86c1-2310ac1bb915 .mouseleave", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getDirectEventFirer(this);
    if(jFirer.is("#m-7d26d58f-Paragraph_9")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Paragraph_10")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_13")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_14")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_15")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_16")) {
      jEvent.undoCases(jFirer);
    } else if(jFirer.is("#m-7d26d58f-Rectangle_22")) {
      jEvent.undoCases(jFirer);
    }
  });