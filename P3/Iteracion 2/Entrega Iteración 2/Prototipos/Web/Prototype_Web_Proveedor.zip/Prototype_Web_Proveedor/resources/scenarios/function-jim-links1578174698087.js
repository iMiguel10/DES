(function(window, undefined) {

  var jimLinks = {
    "3271ed72-dfd4-43ab-a621-213bc153f73d" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_2" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_3" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "dbc1bf04-3315-4276-8c1b-e293d85b600c"
      ]
    },
    "63fbbd0d-84cb-42f1-abfd-348e89aeaaa7" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_3" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Button_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d96e797b-c84d-4b21-8600-5a73454b3316" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_2" : [
        "81a6c3c2-cd0e-4573-aa09-4b1b541d86ec"
      ]
    },
    "a78b7b14-0572-445a-b0fa-7c9ef79dc414" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_4" : [
        "f2afab6c-1a61-4eb8-a4b7-00046ca23ca4"
      ],
      "Hotspot_1" : [
        "dbc1bf04-3315-4276-8c1b-e293d85b600c"
      ]
    },
    "dbc1bf04-3315-4276-8c1b-e293d85b600c" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_2" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ]
    },
    "81a6c3c2-cd0e-4573-aa09-4b1b541d86ec" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_2" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ]
    },
    "4b58098c-2e17-4cde-a4a9-33eb139662a4" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_3" : [
        "63fbbd0d-84cb-42f1-abfd-348e89aeaaa7"
      ],
      "Hotspot_3" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_4" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_2" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "f2afab6c-1a61-4eb8-a4b7-00046ca23ca4"
      ]
    },
    "b1c10549-6910-4cf8-878d-b5789e562d95" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_2" : [
        "b0baafc4-55b1-45c1-bdde-8f468a6635b4"
      ],
      "Hotspot_2" : [
        "b87aa42a-6e1d-486b-80fd-6ed956b49bd6"
      ]
    },
    "f6e4e648-a8e3-4c00-aa42-68ca44600862" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_1" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_2" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_4" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_5" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_9" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_8" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_7" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_6" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ],
      "Hotspot_3" : [
        "d96e797b-c84d-4b21-8600-5a73454b3316"
      ]
    },
    "b87aa42a-6e1d-486b-80fd-6ed956b49bd6" : {
      "Hotspot_1" : [
        "b1c10549-6910-4cf8-878d-b5789e562d95"
      ],
      "Hotspot_2" : [
        "b0baafc4-55b1-45c1-bdde-8f468a6635b4"
      ]
    },
    "7686416f-b060-4211-87c8-35b7bdc23277" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_2" : [
        "63fbbd0d-84cb-42f1-abfd-348e89aeaaa7"
      ],
      "Hotspot_3" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_4" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_2" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "f2afab6c-1a61-4eb8-a4b7-00046ca23ca4"
      ]
    },
    "b0baafc4-55b1-45c1-bdde-8f468a6635b4" : {
      "Button_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "b87aa42a-6e1d-486b-80fd-6ed956b49bd6"
      ]
    },
    "f2afab6c-1a61-4eb8-a4b7-00046ca23ca4" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Button_3" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Button_4" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ]
    },
    "7d26d58f-ecbf-4196-86c1-2310ac1bb915" : {
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_13" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Rectangle_14" : [
        "7686416f-b060-4211-87c8-35b7bdc23277"
      ],
      "Rectangle_15" : [
        "f6e4e648-a8e3-4c00-aa42-68ca44600862"
      ],
      "Rectangle_16" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Rectangle_22" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ],
      "Hotspot_5" : [
        "a78b7b14-0572-445a-b0fa-7c9ef79dc414"
      ],
      "Hotspot_1" : [
        "3271ed72-dfd4-43ab-a621-213bc153f73d"
      ],
      "Hotspot_6" : [
        "4b58098c-2e17-4cde-a4a9-33eb139662a4"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);