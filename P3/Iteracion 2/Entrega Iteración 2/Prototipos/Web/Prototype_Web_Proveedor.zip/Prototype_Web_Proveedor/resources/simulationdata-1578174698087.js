function initData() {
  jimData.datamasters["SubastasOfertadas"] = [
    {
      "id": 1,
      "datamaster": "SubastasOfertadas",
      "userdata": {
        "ID": "1",
        "Proveedor": "Proveedor1",
        "Categoria": "Musica",
        "Descripcion": "Necesito cantante",
        "Precio (\u20ac)": "20",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Comentario": "Ninguno.",
        "Localización": "Granada, UGR"
      }
    },
    {
      "id": 2,
      "datamaster": "SubastasOfertadas",
      "userdata": {
        "ID": "2",
        "Proveedor": "Proveedor2",
        "Categoria": "Comida",
        "Descripcion": "Necesito catering",
        "Precio (\u20ac)": "70",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Comentario": "Comida Indu.",
        "Localización": "Granada"
      }
    }
  ];

  jimData.datamasters["Servicios"] = [
    {
      "id": 1,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "1",
        "Nombre Servicio": "Servicio Musical",
        "Descripcion Servicio": "Descripcion ejemplo",
        "Categoria": "Musica",
        "Tags": "Musica, Indie",
        "Editar": "O",
        "Eliminar": "X",
        "Seleccionar": "Seleccionar"
      }
    },
    {
      "id": 2,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "2",
        "Nombre Servicio": "Servicio Musical 2",
        "Descripcion Servicio": "Descripcion ejemplo",
        "Categoria": "Musica",
        "Tags": "Musica, Heavy Metal",
        "Editar": "O",
        "Eliminar": "X",
        "Seleccionar": "Seleccionar"
      }
    }
  ];

  jimData.datamasters["SubastasParticipadas"] = [
    {
      "id": 1,
      "datamaster": "SubastasParticipadas",
      "userdata": {
        "IDSubasta": "1",
        "IDServicio": "1",
        "Nombre Servicio": "Servicio Musica",
        "Descripcion": "Descripcion ejemplo",
        "Oferta": "50",
        "Estado": "Sobrepujado",
        "Comentario": "Ninguno",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    },
    {
      "id": 2,
      "datamaster": "SubastasParticipadas",
      "userdata": {
        "IDSubasta": "2",
        "IDServicio": "1",
        "Nombre Servicio": "Servicio Musica",
        "Descripcion": "Descripcion ejemplo",
        "Oferta": "70",
        "Estado": "Lider",
        "Comentario": "Ninguno",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    }
  ];

  jimData.isInitialized = true;
}