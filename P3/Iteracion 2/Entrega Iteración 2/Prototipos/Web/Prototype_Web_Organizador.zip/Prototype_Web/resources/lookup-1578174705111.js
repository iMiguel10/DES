(function(window, undefined) {
  var dictionary = {
    "eb2b1781-92d7-4798-8d44-a61a47ea9c52": "Servicio_Detalles",
    "b9682aa3-1118-4faa-91fd-a674626966cd": "Subastas",
    "a3813fea-967c-49d1-82ba-c6651b460282": "Eventos",
    "d6a632a2-3424-4834-9a56-2c1e8f1dab57": "Eventos_listado",
    "a0d438a7-4b7a-49fe-8fd4-57acd77fc6fe": "Subastas_SeleccionGanador",
    "d7a4a422-e966-46c1-8ea6-1fd661224797": "Subastas_Editar",
    "13bab968-be38-4529-a204-ec4a3a368ca7": "Configuracion",
    "65fd819a-cc17-49bb-9d84-dcce8702c236": "Subastas_Crear",
    "b868278d-f449-4a28-ae26-cca562916354": "Home",
    "1e644bef-09d3-4f3e-9c4d-1480f2e736ff": "Eventos_Crear",
    "5edc2a44-c65b-4224-b5af-e9dd95a26b0d": "LogIn",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Onboarding",
    "38123e37-8aba-4c5b-b147-f2f0c28b7478": "Eventos_Editar",
    "63bda210-482a-40d9-b530-06b7d1f8ada1": "Evento_Detalles",
    "8eaba6d2-c59e-472e-a700-09fddbd84738": "Register",
    "e73b655d-d3ec-4dcc-a55c-6e0293422bde": "960 grid - 16 columns",
    "ef07b413-721c-418e-81b1-33a7ed533245": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "dd9131bf-cf78-47fd-9a37-e660d86ff426": "Custom",
    "23141912-2879-46b6-9572-6f87544997b3": "Master",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);