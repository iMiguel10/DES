(function(window, undefined) {

  var jimLinks = {
    "eb2b1781-92d7-4798-8d44-a61a47ea9c52" : {
      "Button_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "b9682aa3-1118-4faa-91fd-a674626966cd" : {
      "Hotspot_3" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "d7a4a422-e966-46c1-8ea6-1fd661224797"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "a3813fea-967c-49d1-82ba-c6651b460282" : {
      "Hotspot_5" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_4" : [
        "38123e37-8aba-4c5b-b147-f2f0c28b7478"
      ],
      "Button_1" : [
        "1e644bef-09d3-4f3e-9c4d-1480f2e736ff"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "d6a632a2-3424-4834-9a56-2c1e8f1dab57" : {
      "Hotspot_2" : [
        "eb2b1781-92d7-4798-8d44-a61a47ea9c52"
      ],
      "Hotspot_3" : [
        "eb2b1781-92d7-4798-8d44-a61a47ea9c52"
      ],
      "Hotspot_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "a0d438a7-4b7a-49fe-8fd4-57acd77fc6fe" : {
      "Hotspot_3" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_2" : [
        "eb2b1781-92d7-4798-8d44-a61a47ea9c52"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "d7a4a422-e966-46c1-8ea6-1fd661224797" : {
      "Button_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "13bab968-be38-4529-a204-ec4a3a368ca7" : {
      "Button_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "65fd819a-cc17-49bb-9d84-dcce8702c236" : {
      "Button_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "b868278d-f449-4a28-ae26-cca562916354" : {
      "Hotspot_5" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_4" : [
        "38123e37-8aba-4c5b-b147-f2f0c28b7478"
      ],
      "Button_1" : [
        "1e644bef-09d3-4f3e-9c4d-1480f2e736ff"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "1e644bef-09d3-4f3e-9c4d-1480f2e736ff" : {
      "Button_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Button_2" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "5edc2a44-c65b-4224-b5af-e9dd95a26b0d" : {
      "Button_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Text_1" : [
        "8eaba6d2-c59e-472e-a700-09fddbd84738"
      ],
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Login" : [
        "5edc2a44-c65b-4224-b5af-e9dd95a26b0d"
      ],
      "Signin" : [
        "8eaba6d2-c59e-472e-a700-09fddbd84738"
      ]
    },
    "38123e37-8aba-4c5b-b147-f2f0c28b7478" : {
      "Button_1" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Button_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "63bda210-482a-40d9-b530-06b7d1f8ada1" : {
      "Button_2" : [
        "65fd819a-cc17-49bb-9d84-dcce8702c236"
      ],
      "Button_3" : [
        "d6a632a2-3424-4834-9a56-2c1e8f1dab57"
      ],
      "Hotspot_2" : [
        "38123e37-8aba-4c5b-b147-f2f0c28b7478"
      ],
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "8eaba6d2-c59e-472e-a700-09fddbd84738" : {
      "Button_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "dd9131bf-cf78-47fd-9a37-e660d86ff426" : {
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    },
    "23141912-2879-46b6-9572-6f87544997b3" : {
      "Hotspot_1" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_9" : [
        "b868278d-f449-4a28-ae26-cca562916354"
      ],
      "Rectangle_10" : [
        "a3813fea-967c-49d1-82ba-c6651b460282"
      ],
      "Rectangle_11" : [
        "b9682aa3-1118-4faa-91fd-a674626966cd"
      ],
      "Rectangle_12" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ],
      "Hotspot_2" : [
        "63bda210-482a-40d9-b530-06b7d1f8ada1"
      ],
      "Hotspot_3" : [
        "13bab968-be38-4529-a204-ec4a3a368ca7"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);