function initData() {
  jimData.variables["Eventos"] = "";
  jimData.variables["Servicios"] = "";
  jimData.datamasters["Eventos"] = [
    {
      "id": 1,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "1",
        "Nombre Evento": "Evento musica",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Musica",
        "Estado": "Abierto",
        "Editar": "O",
        "Eliminar": "X"
      }
    },
    {
      "id": 2,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "2",
        "Nombre Evento": "Evento fiesta",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Fiesta, Musica",
        "Estado": "Abierto",
        "Editar": "O",
        "Eliminar": "X"
      }
    },
    {
      "id": 3,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "3",
        "Nombre Evento": "Evento musical",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Musica",
        "Estado": "Cerrado",
        "Editar": "O",
        "Eliminar": "X"
      }
    },
    {
      "id": 4,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "4",
        "Nombre Evento": "Evento Concierto",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Musica, Hall",
        "Estado": "Cerrado",
        "Editar": "O",
        "Eliminar": "X"
      }
    },
    {
      "id": 5,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "5",
        "Nombre Evento": "Evento DJ",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Musica, DJ, Campo",
        "Estado": "Abierto",
        "Editar": "O",
        "Eliminar": "X"
      }
    },
    {
      "id": 6,
      "datamaster": "Eventos",
      "userdata": {
        "ID": "6",
        "Nombre Evento": "Evento Camping",
        "Descripción": "Este es un texto descriptivo de ejemplo.",
        "Tags": "Campo, Comida",
        "Estado": "Cerrado",
        "Editar": "O",
        "Eliminar": "X"
      }
    }
  ];

  jimData.datamasters["ServiciosContratados"] = [
    {
      "id": 1,
      "datamaster": "ServiciosContratados",
      "userdata": {
        "ID": "1",
        "Nombre Servicio": "Musico Indi",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Musica",
        "Tags": "Musica, Indie",
        "Estado": "Aceptado",
        "Quitar": "-"
      }
    },
    {
      "id": 2,
      "datamaster": "ServiciosContratados",
      "userdata": {
        "ID": "2",
        "Nombre Servicio": "Servicio Catering",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Comida",
        "Tags": "Catering",
        "Estado": "Pendiente",
        "Quitar": "-"
      }
    },
    {
      "id": 3,
      "datamaster": "ServiciosContratados",
      "userdata": {
        "ID": "3",
        "Nombre Servicio": "Iluminaciones Paco",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Iluminación",
        "Tags": "Iluminación, Luz",
        "Estado": "Aceptado",
        "Quitar": "-"
      }
    }
  ];

  jimData.datamasters["ServiciosContratadosSubasta"] = [
    {
      "id": 1,
      "datamaster": "ServiciosContratadosSubasta",
      "userdata": {
        "IDEvento": "1",
        "IDServicio": "1",
        "Nombre Servicio": "Musico Indi",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Musica",
        "Tags": "Musica, Indie",
        "Oferta": "Aceptado",
        "NombreEvento": "Evento Musica",
        "Seleccionar Ganador": "Seleccionar"
      }
    },
    {
      "id": 2,
      "datamaster": "ServiciosContratadosSubasta",
      "userdata": {
        "IDEvento": "1",
        "IDServicio": "2",
        "Nombre Servicio": "Servicio Catering",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Comida",
        "Tags": "Catering",
        "Oferta": "Pendiente",
        "NombreEvento": "Evento Musica",
        "Seleccionar Ganador": "Seleccionar"
      }
    },
    {
      "id": 3,
      "datamaster": "ServiciosContratadosSubasta",
      "userdata": {
        "IDEvento": "5",
        "IDServicio": "3",
        "Nombre Servicio": "Iluminaciones Paco",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Iluminación",
        "Tags": "Iluminación, Luz",
        "Oferta": "Aceptado",
        "NombreEvento": "Evento Camping",
        "Seleccionar Ganador": "Seleccionar"
      }
    }
  ];

  jimData.datamasters["Servicios"] = [
    {
      "id": 1,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "1",
        "Nombre Servicio": "Musico Indi",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Musica",
        "Tags": "Musica, Indie",
        "Añadir": "+"
      }
    },
    {
      "id": 2,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "2",
        "Nombre Servicio": "Servicio Catering",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Comida",
        "Tags": "Catering",
        "Añadir": "+"
      }
    },
    {
      "id": 3,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "3",
        "Nombre Servicio": "Iluminaciones Paco",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Iluminación",
        "Tags": "Iluminación, Luz",
        "Añadir": "+"
      }
    },
    {
      "id": 4,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "4",
        "Nombre Servicio": "Grupo Heavy Metal",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Musica",
        "Tags": "Musica, Heavy Metal",
        "Añadir": "+"
      }
    },
    {
      "id": 5,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "5",
        "Nombre Servicio": "Servicios de transportes",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Transporte",
        "Tags": "Transporte",
        "Añadir": "+"
      }
    },
    {
      "id": 6,
      "datamaster": "Servicios",
      "userdata": {
        "ID": "6",
        "Nombre Servicio": "Alquiler de Carpas",
        "Descripcion": "Descipcion de ejemplo.",
        "Categoria": "Material",
        "Tags": "Carpas, Material",
        "Añadir": "+"
      }
    }
  ];

  jimData.datamasters["Subastas"] = [
    {
      "id": 1,
      "datamaster": "Subastas",
      "userdata": {
        "ID": "1",
        "Precio Maximo": "100\u20ac",
        "Categoria": "Musica",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Metodo de Seleccion de Ganador": "Seleccion de Ganador",
        "Descripcion o comentarios adicionales": "Ninguno.",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    },
    {
      "id": 2,
      "datamaster": "Subastas",
      "userdata": {
        "ID": "2",
        "Precio Maximo": "200\u20ac",
        "Categoria": "Musica",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Metodo de Seleccion de Ganador": "Mejor Postor",
        "Descripcion o comentarios adicionales": "Solo musicos Indie.",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    },
    {
      "id": 3,
      "datamaster": "Subastas",
      "userdata": {
        "ID": "3",
        "Precio Maximo": "250\u20ac",
        "Categoria": "Musica",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Metodo de Seleccion de Ganador": "Mejor Postor",
        "Descripcion o comentarios adicionales": "Ninguno.",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    },
    {
      "id": 4,
      "datamaster": "Subastas",
      "userdata": {
        "ID": "4",
        "Precio Maximo": "50\u20ac",
        "Categoria": "Comida",
        "Fecha de Inicio": "09/12/2011",
        "Fecha de Fin": "09/12/2011",
        "Metodo de Seleccion de Ganador": "Seleccion de Ganador",
        "Descripcion o comentarios adicionales": "Solo comida Indu.",
        "Editar": "Editar",
        "Eliminar": "X"
      }
    }
  ];

  jimData.isInitialized = true;
}