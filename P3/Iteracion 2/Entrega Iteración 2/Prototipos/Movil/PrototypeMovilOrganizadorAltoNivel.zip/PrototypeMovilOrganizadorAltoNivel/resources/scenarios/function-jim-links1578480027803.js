(function(window, undefined) {

  var jimLinks = {
    "5deb87bd-10a8-41c5-9878-c7de27de7cf6" : {
      "Ellipse_8" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Image_17" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Image_45" : [
        "dd1711d9-751e-4341-9d73-a3b1e6644789"
      ],
      "Image_71" : [
        "995c5d03-93a2-4d5b-9fe2-5496140674fd"
      ],
      "Image_76" : [
        "c98b3693-1609-493d-940b-3faad13f0be7"
      ]
    },
    "44436231-99e3-498f-9462-7c5383f022d4" : {
      "Image_72" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Ellipse_8" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Image_21" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ]
    },
    "dd1711d9-751e-4341-9d73-a3b1e6644789" : {
      "Image_71" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ],
      "Rectangle_4" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ]
    },
    "c895109f-7d66-4877-8a79-a4855e267921" : {
      "Hotspot_1" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ]
    },
    "4d78b9c4-d1f7-47e9-ad7d-bbf880a076ea" : {
      "Image_71" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ]
    },
    "1e837ed6-fb5f-4c8e-96f2-71e6b7eb6a09" : {
      "Ellipse_8" : [
        "1f0667cb-54e0-4a5c-800a-1dc456f87e0f"
      ],
      "Image_45" : [
        "dd1711d9-751e-4341-9d73-a3b1e6644789"
      ],
      "Image_71" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Image_76" : [
        "c98b3693-1609-493d-940b-3faad13f0be7"
      ],
      "Image_81" : [
        "1f0667cb-54e0-4a5c-800a-1dc456f87e0f"
      ]
    },
    "995c5d03-93a2-4d5b-9fe2-5496140674fd" : {
      "Image_71" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "Image_17" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ]
    },
    "c98b3693-1609-493d-940b-3faad13f0be7" : {
      "Image_71" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ],
      "Ellipse_8" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ],
      "Image_17" : [
        "5deb87bd-10a8-41c5-9878-c7de27de7cf6"
      ]
    },
    "1f0667cb-54e0-4a5c-800a-1dc456f87e0f" : {
      "Ellipse_8" : [
        "1e837ed6-fb5f-4c8e-96f2-71e6b7eb6a09"
      ],
      "Image_21" : [
        "1e837ed6-fb5f-4c8e-96f2-71e6b7eb6a09"
      ],
      "Image_72" : [
        "1e837ed6-fb5f-4c8e-96f2-71e6b7eb6a09"
      ]
    },
    "0d66e5ff-6fa6-4104-9242-ba90af648656" : {
      "raised_Button" : [
        "c895109f-7d66-4877-8a79-a4855e267921"
      ],
      "raised_Button_1" : [
        "6b9ffe04-4ed6-4d96-9f5d-9b9ed340aed1"
      ]
    },
    "d4b6769f-0d24-4a9d-9b4a-5708500b5531" : {
      "Image_2" : [
        "44436231-99e3-498f-9462-7c5383f022d4"
      ],
      "plus_2" : [
        "995c5d03-93a2-4d5b-9fe2-5496140674fd"
      ],
      "Image_71" : [
        "4d78b9c4-d1f7-47e9-ad7d-bbf880a076ea"
      ],
      "Rectangle_4" : [
        "1e837ed6-fb5f-4c8e-96f2-71e6b7eb6a09"
      ]
    },
    "6b9ffe04-4ed6-4d96-9f5d-9b9ed340aed1" : {
      "raised_Button" : [
        "d4b6769f-0d24-4a9d-9b4a-5708500b5531"
      ],
      "raised_Button_1" : [
        "0d66e5ff-6fa6-4104-9242-ba90af648656"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);