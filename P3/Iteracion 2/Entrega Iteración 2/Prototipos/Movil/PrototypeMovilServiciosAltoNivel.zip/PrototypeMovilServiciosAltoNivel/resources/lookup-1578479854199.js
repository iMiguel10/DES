(function(window, undefined) {
  var dictionary = {
    "44436231-99e3-498f-9462-7c5383f022d4": "EditarUsuarioScreen",
    "5deb87bd-10a8-41c5-9878-c7de27de7cf6": "ConsultarServicioScreen",
    "dd1711d9-751e-4341-9d73-a3b1e6644789": "SubastaScreen",
    "c895109f-7d66-4877-8a79-a4855e267921": "planner-3485976_1920",
    "4d78b9c4-d1f7-47e9-ad7d-bbf880a076ea": "NotificacionesScreen",
    "995c5d03-93a2-4d5b-9fe2-5496140674fd": "NuevoServicioScreen",
    "1f0667cb-54e0-4a5c-800a-1dc456f87e0f": "EditarServicioScreen",
    "c98b3693-1609-493d-940b-3faad13f0be7": "PujaEventoScreen",
    "0d66e5ff-6fa6-4104-9242-ba90af648656": "RegistrarUsuarioScreen",
    "d4b6769f-0d24-4a9d-9b4a-5708500b5531": "ProveedorScreen",
    "6b9ffe04-4ed6-4d96-9f5d-9b9ed340aed1": "furniture-731449_1280",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);